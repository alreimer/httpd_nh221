#!/bin/sh
#############################################
# made by alex_raw
# usage:
# $1 = serialnumber
# $2 = partition number

. /etc/config


if [ -n "$BACKUP_PATH" ]; then
    TO=$BACKUP_PATH
else
    TO=/mnt/home/usb_backup
fi

#2-toggle HD_FULL flash
#3-toggle BACKUP flash
/sbin/nh23X_ioctl 3 > /dev/null

for i in `cat /etc/known_usb | grep -v "#" | grep $1`
    do
	if [ -n "$1" ]; then
	S=`echo $i | cut -d ":" -f 1`
	    if [ "$S" == "$1" ]; then
		P=`echo $i | cut -d ":" -f 2 `
		M=`echo $i | cut -d ":" -f 3 `
		if [ -z "$M" ]; then
		    M=/mnt/home/usb/$1
		fi
		if [ "$P" == "$2" ]; then
		    if [ "$P" == "*" ]; then
			mkdir -p "$TO/$S"
			cp -ar "$M/"* "$TO/$S/"
		    else
			mkdir -p "$TO/$S_$P"
			cp -ar "$M/"* "$TO/$S_$P/"
		    fi
		sync; sync
		fi
	    fi
	fi
done

/sbin/nh23X_ioctl 3 > /dev/null
