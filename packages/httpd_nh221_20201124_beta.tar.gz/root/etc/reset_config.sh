#!/bin/sh

sync;sync;sync;
cd /; /bin/umount /etc && /sbin/reboot &
