move:
this folder (web) to /web
mnt/* to /mnt
etc/* to /etc
copy services/* to /mnt/services, and make link from /mnt/services to /web/services